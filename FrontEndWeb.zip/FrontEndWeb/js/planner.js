function goBack() {
    window.location.href = "ToDoList.html";
  }
  
  document.addEventListener("DOMContentLoaded", () => {
    const calendar = document.getElementById("calendar");
    const days = ["Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс"];
  
   
    days.forEach(day => {
      const div = document.createElement("div");
      div.textContent = day;
      div.style.backgroundColor = "#d6eaf8";
      calendar.appendChild(div);
    });
  
    
    for (let i = 1; i <= 30; i++) {
      const day = document.createElement("div");
      day.textContent = i;
      calendar.appendChild(day);
    }
  });
  