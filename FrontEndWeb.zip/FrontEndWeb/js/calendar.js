function getSelectedDate() {
    const dateInput = document.getElementById("datePicker");
    return dateInput.value;
  }
  
  function addCalendarTask() {
    const date = getSelectedDate();
    const taskInput = document.getElementById("calendarTaskInput");
    const taskText = taskInput.value.trim();
  
    if (!date || !taskText) return;
  
    const tasks = JSON.parse(localStorage.getItem("calendarTasks")) || {};
  
    if (!tasks[date]) {
      tasks[date] = [];
    }
  
    tasks[date].push({ text: taskText, completed: false });
    localStorage.setItem("calendarTasks", JSON.stringify(tasks));
  
    taskInput.value = "";
    displayTasksForDate(date);
  }
  
  function displayTasksForDate(date) {
    const taskList = document.getElementById("calendarTaskList");
    taskList.innerHTML = "";
  
    const tasks = JSON.parse(localStorage.getItem("calendarTasks")) || {};
  
    if (tasks[date]) {
      tasks[date].forEach((task, index) => {
        const li = document.createElement("li");
  
        
        const label = document.createElement("label");
        const checkbox = document.createElement("input");
        checkbox.type = "checkbox";
        checkbox.checked = task.completed;
        checkbox.addEventListener("change", () => toggleComplete(date, index));
  
        const span = document.createElement("span");
        span.textContent = task.text;
        if (task.completed) {
          span.style.textDecoration = "line-through";
          span.style.opacity = "0.6";
        }
  
        label.appendChild(checkbox);
        label.appendChild(span);
  
        
        const deleteBtn = document.createElement("button");
        deleteBtn.innerHTML = "✖";
        deleteBtn.className = "delete-btn";
        deleteBtn.onclick = () => deleteTask(date, index);
  
        li.appendChild(label);
        li.appendChild(deleteBtn);
  
        taskList.appendChild(li);
      });
    }
  }
  
  function deleteTask(date, index) {
    const tasks = JSON.parse(localStorage.getItem("calendarTasks")) || {};
    if (tasks[date]) {
      tasks[date].splice(index, 1);
      if (tasks[date].length === 0) delete tasks[date];
      localStorage.setItem("calendarTasks", JSON.stringify(tasks));
      displayTasksForDate(date);
    }
  }
  
  function toggleComplete(date, index) {
    const tasks = JSON.parse(localStorage.getItem("calendarTasks")) || {};
    if (tasks[date] && tasks[date][index]) {
      tasks[date][index].completed = !tasks[date][index].completed;
      localStorage.setItem("calendarTasks", JSON.stringify(tasks));
      displayTasksForDate(date);
    }
  }
  
  
  document.getElementById("datePicker").addEventListener("change", () => {
    const date = getSelectedDate();
    displayTasksForDate(date);
  });
  