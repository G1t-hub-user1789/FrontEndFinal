window.onload = function () {
  alert("Welcome to Task-Flow!");
};

let loginAttempts = 0;

function login(event) {
  event.preventDefault();
  loginAttempts++;
  const username = document.getElementById("username").value;
  const password = document.getElementById("password").value;
  const storedUser = JSON.parse(localStorage.getItem("user"));

  if (storedUser && storedUser.username === username && storedUser.password === password) {
    window.location.href = "ToDoList.html";
  } else {
    alert(`Неверные данные. Попытка №${loginAttempts}`);
  }
}



function register(event) {
    event.preventDefault();
    const username = document.getElementById("newUsername").value;
    const password = document.getElementById("newPassword").value;

    localStorage.setItem("user", JSON.stringify({ username, password }));

    
    window.location.href = "ToDoList.html";
  }
  