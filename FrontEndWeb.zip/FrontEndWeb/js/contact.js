function goBack() {
    window.location.href = "ToDoList.html";
  }
  
  document.getElementById("contactForm").addEventListener("submit", function (e) {
    e.preventDefault();
    document.getElementById("response").textContent = "Спасибо за сообщение! Мы свяжемся с вами.";
    this.reset();
  });
  