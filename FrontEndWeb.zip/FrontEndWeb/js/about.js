function goBack() {
  window.location.href = "ToDoList.html";
}

window.onload = () => {
  
  const tasks = JSON.parse(localStorage.getItem("tasks")) || [];

  // Задачи с календаря
  const calendarTasks = JSON.parse(localStorage.getItem("calendarTasks")) || {};
  let calendarTaskCount = 0;

  
  for (const date in calendarTasks) {
    if (Array.isArray(calendarTasks[date])) {
      calendarTaskCount += calendarTasks[date].length;
    }
  }

  const totalTaskCount = tasks.length + calendarTaskCount;

  document.getElementById("taskCount").textContent = totalTaskCount;
};
