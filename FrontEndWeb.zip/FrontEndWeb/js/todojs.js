

document.addEventListener("DOMContentLoaded", () => {
  loadTasks();
  loadDiary();
  updateDiaryHistory();
  renderGoals();
  renderHabitCards();
  updateTaskSelectors();
  fetchQuote();

  document.getElementById("taskInput")?.addEventListener("keydown", (e) => {
    if (e.key === "Enter") addTask();
  });
  document.getElementById("addGoalBtn").addEventListener("click", () => {
    const input = document.getElementById("goalInput");
    const value = input.value.trim();
    if (value) {
      goals.push(value);
      renderGoals();
      input.value = "";
    }
  });
});


function addTask() {
  const input = document.getElementById("taskInput");
  const priority = document.getElementById("prioritySelect").value;
  const text = input.value.trim();

  if (!text || text.length > 200) return;

  const task = createTaskElement(text, false, priority);
  document.getElementById("taskList").appendChild(task);
  input.value = "";
  saveTasks();
}

function saveTasks() {
  const tasks = [];
  document.querySelectorAll("#taskList li").forEach(li => {
    const text = li.querySelector("span").textContent;
    const completed = li.classList.contains("completed");
    const priority = li.className.includes("task-high") ? "high" :
                     li.className.includes("task-medium") ? "medium" : "low";
    tasks.push({ text, completed, priority });
  });
  localStorage.setItem("tasks", JSON.stringify(tasks));
  updateTaskSelectors();
}

function loadTasks() {
  const tasks = JSON.parse(localStorage.getItem("tasks")) || [];
  const taskList = document.getElementById("taskList");
  tasks.forEach(({ text, completed, priority }) => {
    const li = createTaskElement(text, completed, priority);
    taskList.appendChild(li);
  });
}



function saveDiary() {
  const date = document.getElementById("diaryDate").value;
  const title = document.getElementById("diaryTitle").value.trim();
  const text = document.getElementById("diaryEntry").value.trim();

  if (!date || (!title && !text)) {
    return setDiaryStatus("⚠ Заполните дату и хотя бы одно поле.");
  }

  localStorage.setItem("diary_" + date, JSON.stringify({ title, text }));
  setDiaryStatus("✅ Запись сохранена.");
  updateDiaryHistory();
}

function clearDiary() {
  const date = document.getElementById("diaryDate").value;
  if (date) localStorage.removeItem("diary_" + date);

  document.getElementById("diaryTitle").value = "";
  document.getElementById("diaryEntry").value = "";
  setDiaryStatus("🗑 Запись очищена.");
  updateDiaryHistory();
}

function loadDiary() {
  const dateInput = document.getElementById("diaryDate");
  const titleInput = document.getElementById("diaryTitle");
  const textArea = document.getElementById("diaryEntry");

  const today = new Date().toISOString().split("T")[0];
  dateInput.value = today;

  const saved = localStorage.getItem("diary_" + today);
  if (saved) {
    const { title, text } = JSON.parse(saved);
    titleInput.value = title || "";
    textArea.value = text || "";
    setDiaryStatus("📖 Загружена запись за сегодня.");
  } else {
    titleInput.value = "";
    textArea.value = "";
    setDiaryStatus("ℹ Нет записи на сегодня.");
  }
}

function updateDiaryHistory() {
  const history = document.getElementById("diaryHistory");
  if (!history) return;

  history.innerHTML = "";

  const entries = Object.keys(localStorage)
    .filter(key => key.startsWith("diary_"))
    .sort((a, b) => b.localeCompare(a));

  entries.forEach(key => {
    const date = key.replace("diary_", "");
    const { title } = JSON.parse(localStorage.getItem(key));

    const li = document.createElement("li");
    li.className = "list-group-item d-flex justify-content-between align-items-center";
    li.innerHTML = `
      <div><strong>${date}</strong>: ${title || "(без заголовка)"}</div>
      <button class="btn btn-sm btn-outline-info" onclick="loadDiaryEntry('${date}')">Открыть</button>
    `;
    history.appendChild(li);
  });
}


const goals = [];
function renderGoals() {
  const list = document.getElementById("goalList");
  if (!list) return;
  list.innerHTML = "";
  goals.forEach(goal => {
    const li = document.createElement("li");
    li.className = "list-group-item";
    li.textContent = goal;
    list.appendChild(li);
  });
}

document.getElementById("addGoalBtn")?.addEventListener("click", () => {
  const input = document.getElementById("goalInput");
  const value = input.value.trim();
  if (value) {
    goals.push(value);
    renderGoals();
    input.value = "";
  }
});

const habits = [
  "🕒 Ложиться до 23:00", "🚰 Стакан воды с утра", "📖 Читать 5 страниц в день",
  "🧘 Медитация", "📓 Ведение дневника", "💡 Учить новое"
];
function renderHabitCards() {
  const container = document.getElementById("habitCards");
  if (!container) return;
  container.innerHTML = "";
  habits.forEach((habit, index) => {
    const div = document.createElement("div");
    div.className = "p-2 text-white rounded";
    div.style.backgroundColor = index % 2 === 0 ? "#0d6efd" : "#198754";
    div.textContent = habit;
    container.appendChild(div);
  });
}


function loadDiaryEntry(date) {
  const data = localStorage.getItem("diary_" + date);
  if (!data) return;

  const { title, text } = JSON.parse(data);
  document.getElementById("diaryDate").value = date;
  document.getElementById("diaryTitle").value = title || "";
  document.getElementById("diaryEntry").value = text || "";
  setDiaryStatus(`📂 Загружена запись за ${date}`);
}

function setDiaryStatus(message) {
  const status = document.getElementById("diaryStatus");
  if (status) status.textContent = message;
}
const tips = [
  "🧠 Совет: Начинай день с самой важной задачи!",
  "🎯 Цель дня: Заверши хотя бы одну большую задачу.",
  "⏰ Маленькие шаги — путь к большой цели.",
  "📓 Записывай мысли в дневник — это помогает разгрузить ум."
];
const randomTip = tips[Math.floor(Math.random() * tips.length)];
const tipElement = document.createElement("p");
tipElement.textContent = randomTip;
tipElement.className = "alert alert-info";
document.querySelector("main").prepend(tipElement);

// 1. 🎲 Мотивация дня
function generateMotivation() {
  const score = Math.floor(Math.random() * 100) + 1;
  let mood = (score % 2 === 0) ? "структурированный" : "спонтанный";
  let energy = (score > 50) ? "высокая мотивация" : "не забывай отдыхать";
  const msg = `🎯 Оценка дня: ${score} — ${mood} день, ${energy}.`;
  document.getElementById("motivationResult").textContent = msg;
}


//музыкаааааааааа ыаоыоаыоаоааыоаыаыоаооыаоыа саундтреки имба
let isPlaying = false;
const audio = document.getElementById("audioPlayer");
const playPauseBtn = document.getElementById("playPauseBtn");
const progressBar = document.getElementById("progressBar");

function toggleAudio() {
  if (audio.paused) {
    audio.play();
    playPauseBtn.textContent = "⏸ Пауза";
  } else {
    audio.pause();
    playPauseBtn.textContent = "▶ Воспроизвести";
  }
}

function rewindAudio() {
  audio.currentTime = Math.max(0, audio.currentTime - 10);
}

function forwardAudio() {
  audio.currentTime = Math.min(audio.duration, audio.currentTime + 10);
}

audio.addEventListener("timeupdate", () => {
  progressBar.value = audio.currentTime;
  progressBar.max = audio.duration;
});

progressBar.addEventListener("input", () => {
  audio.currentTime = progressBar.value;
});

function createTaskElement(text, completed, priority = "low") {
  const li = document.createElement("li");
  li.className = `task-${priority} list-group-item d-flex justify-content-between align-items-center`;
  if (completed) li.classList.add("completed");

  const span = document.createElement("span");
  span.textContent = text;
  span.style.cursor = "pointer";

  // ✅ Клик по тексту переключает завершение
  span.addEventListener("click", () => {
    li.classList.toggle("completed");
    saveTasks();
  });

  // ✏️ Кнопка «Редактировать» (встроенное редактирование)
  const edit = document.createElement("button");
  edit.className = "btn btn-sm btn-outline-secondary me-1";
  edit.innerHTML = '<i class="fas fa-pen"></i>';
  edit.onclick = (e) => {
    e.stopPropagation();

    // Создаём input и заменяем span
    const input = document.createElement("input");
    input.type = "text";
    input.value = span.textContent;
    input.className = "form-control me-2";
    input.style.maxWidth = "200px";

    // Когда пользователь закончил редактировать
    input.addEventListener("blur", () => {
      const newText = input.value.trim();
      if (newText) {
        span.textContent = newText;
        input.replaceWith(span);
        saveTasks();
      } else {
        input.replaceWith(span);
      }
    });

    // Enter = подтвердить
    input.addEventListener("keydown", (e) => {
      if (e.key === "Enter") input.blur();
    });

    span.replaceWith(input);
    input.focus();
  };

  // 🗑 Кнопка удалить
  const del = document.createElement("button");
  del.className = "btn btn-sm btn-danger";
  del.innerHTML = '<i class="fas fa-trash"></i>';
  del.onclick = (e) => {
    e.stopPropagation();
    li.remove();
    saveTasks();
  };

  const controlDiv = document.createElement("div");
  controlDiv.append(edit, del);

  li.append(span, controlDiv);
  return li;
}

function updateTaskSelectors() {
  const taskASelect = document.getElementById("taskA");
  const taskBSelect = document.getElementById("taskB");
  if (!taskASelect || !taskBSelect) return;

  const tasks = JSON.parse(localStorage.getItem("tasks")) || [];
  taskASelect.innerHTML = "";
  taskBSelect.innerHTML = "";

  tasks.forEach((task, index) => {
    const optionA = new Option(task.text, index);
    const optionB = new Option(task.text, index);
    taskASelect.add(optionA);
    taskBSelect.add(optionB);
  });
}


function compareTaskPriorities() {
  const indexA = document.getElementById("taskA").value;
  const indexB = document.getElementById("taskB").value;
  const prioA = Number(document.getElementById("priorityA").value);
  const prioB = Number(document.getElementById("priorityB").value);

  const taskA = document.getElementById("taskA").options[document.getElementById("taskA").selectedIndex].text;
  const taskB = document.getElementById("taskB").options[document.getElementById("taskB").selectedIndex].text;

  let result = "";

  if (prioA > prioB) {
    result = `🔺 Задача A (${taskA}) важнее, чем Задача B (${taskB}).`;
  } else if (prioA < prioB) {
    result = `🔻 Задача B (${taskB}) важнее, чем Задача A (${taskA}).`;
  } else {
    result = `⚖ Задачи A и B равны по приоритету.`;
  }

  document.getElementById("priorityResult").textContent = result;
}


function fetchQuote() {
  fetch("https://dummyjson.com/quotes/random")
    .then(res => {
      if (!res.ok) throw new Error("Сеть ответила с ошибкой.");
      return res.json();
    })
    .then(data => {
      document.getElementById("quoteText").textContent = `"${data.quote}"`;
      document.getElementById("quoteAuthor").textContent = `— ${data.author || "Неизвестный автор"}`;
    })
    .catch(err => {
      console.error("Ошибка API:", err);
      document.getElementById("quoteText").textContent = "⚠ Не удалось загрузить цитату.";
      document.getElementById("quoteAuthor").textContent = "";
    });
}

